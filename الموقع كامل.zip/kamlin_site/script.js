const upload = document.getElementById('imageUpload');
const gallery = document.getElementById('gallery');
let savedImages = JSON.parse(localStorage.getItem('kamlinGallery') || '[]');

function renderGallery(){
  gallery.innerHTML = '';
  savedImages.forEach((src, index) => {
    const item = document.createElement('div');
    item.className = 'gallery-item';
    item.innerHTML = `<button onclick="deleteImage(${index})">حذف</button><img src="${src}" alt="Kamlin before after image">`;
    gallery.appendChild(item);
  });
}

upload.addEventListener('change', function(){
  [...this.files].forEach(file => {
    const reader = new FileReader();
    reader.onload = e => {
      savedImages.push(e.target.result);
      localStorage.setItem('kamlinGallery', JSON.stringify(savedImages));
      renderGallery();
    };
    reader.readAsDataURL(file);
  });
});

function deleteImage(index){
  savedImages.splice(index, 1);
  localStorage.setItem('kamlinGallery', JSON.stringify(savedImages));
  renderGallery();
}

function sendWhatsApp(event){
  event.preventDefault();
  const name = document.getElementById('name').value;
  const area = document.getElementById('area').value;
  const details = document.getElementById('details').value;
  const message = `طلب خدمة تنظيف من موقع كاملين%0Aالاسم: ${name}%0Aالمنطقة: ${area}%0Aالتفاصيل: ${details}`;
  window.open(`https://wa.me/4740949082?text=${message}`, '_blank');
}

renderGallery();
